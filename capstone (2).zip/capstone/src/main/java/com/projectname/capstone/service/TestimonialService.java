package com.projectname.capstone.service;

import com.projectname.capstone.models.Testimonial;
import com.projectname.capstone.repositories.TestimonialRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TestimonialService {

    private final TestimonialRepository testimonialRepository;

    @Autowired
    public TestimonialService(TestimonialRepository testimonialRepository) {
        this.testimonialRepository = testimonialRepository;
    }

    public Testimonial getHeaderMessage() {
        return testimonialRepository.findByIsHeaderTrue().orElse(null);
    }

    public List<Testimonial> getAllTestimonials() {
        return testimonialRepository.findAllByIsHeaderFalse();
    }

    public void saveTestimonial(Testimonial testimonial) {
        testimonial.setHeader(false); // Ensure all new entries are regular testimonials
        testimonialRepository.save(testimonial);
    }

    public void deleteTestimonial(Long id) {
        testimonialRepository.deleteById(id);
    }
}