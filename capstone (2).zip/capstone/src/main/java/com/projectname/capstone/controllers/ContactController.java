package com.projectname.capstone.controllers;

import com.projectname.capstone.models.Contact;
import com.projectname.capstone.service.ContactService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ModelAttribute;

@Controller
@RequestMapping("/contact")
public class ContactController {

    private final ContactService contactService;

    @Autowired
    public ContactController(ContactService contactService) {
        this.contactService = contactService;
    }

    @GetMapping
    public String getContactPage(Model model) {
        model.addAttribute("contact", new Contact()); // Provide a blank form
        return "contact"; // Refers to contact.html in the templates folder
    }

    @PostMapping("/submit")
    public String submitContactForm(@ModelAttribute Contact contact) {
        contactService.saveContact(contact);
        return "redirect:/contact"; // Redirect back to the contact page
    }
}
