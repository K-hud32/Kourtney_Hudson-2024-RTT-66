package com.projectname.capstone.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import com.projectname.capstone.models.Portfolio;
import com.projectname.capstone.service.PortfolioService;


@Controller
@RequestMapping("/portfolio")
public class PortfolioController {

    private final PortfolioService portfolioService;

    @Autowired
    public PortfolioController(PortfolioService portfolioService) {
        this.portfolioService = portfolioService;
    }

    @GetMapping
    public String listPortfolioItems(Model model) {
        // Retrieve portfolio items and add them to the model
        model.addAttribute("portfolioItems", portfolioService.getAllPortfolios());
        return "portfolio"; // Refers to portfolio.html in the templates folder
    }
    @PostMapping("/add")
    public String addPortfolioItem(@ModelAttribute Portfolio portfolio) {
        portfolioService.savePortfolio(portfolio);
        return "redirect:/portfolio"; // Redirect back to the portfolio page
    }

    @PostMapping("/delete/{id}")
    public String deletePortfolioItem(@PathVariable Long id) {
        portfolioService.deletePortfolio(id);
        return "redirect:/portfolio";
    }

    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable Long id, Model model) {
        Portfolio portfolio = portfolioService.getPortfolioById(id);
        model.addAttribute("portfolio", portfolio);
        return "edit-portfolio";
    }

    @PostMapping("/update")
    public String updatePortfolioItem(@ModelAttribute Portfolio portfolio) {
        portfolioService.updatePortfolio(portfolio);
        return "redirect:/portfolio";
    }
}

