package com.projectname.capstone.controllers;

import com.projectname.capstone.service.AboutService;
import com.projectname.capstone.models.About;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/about")
public class AboutController {

    private final AboutService aboutService;

    @Autowired
    public AboutController(AboutService aboutService) {
        this.aboutService = aboutService;
    }

    @GetMapping
    public String aboutPage(Model model) {
        About about = aboutService.getAboutInfo();
        model.addAttribute("about", about);
        return "about";
    }
}
