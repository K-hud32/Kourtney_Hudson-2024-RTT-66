package com.projectname.capstone.repositories;

import com.projectname.capstone.models.Testimonial;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.List;


@Repository
public interface TestimonialRepository extends JpaRepository<Testimonial, Long> {

    // Find the header message
    Optional<Testimonial> findByIsHeaderTrue();

    // Get all testimonials excluding the header
    List<Testimonial> findAllByIsHeaderFalse();
}
