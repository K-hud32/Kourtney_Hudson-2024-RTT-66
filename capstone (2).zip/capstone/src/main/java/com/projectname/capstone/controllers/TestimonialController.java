package com.projectname.capstone.controllers;

import com.projectname.capstone.models.Testimonial;
import com.projectname.capstone.service.TestimonialService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/testimonials")
public class TestimonialController {

    private final TestimonialService testimonialService;

    @Autowired
    public TestimonialController(TestimonialService testimonialService) {
        this.testimonialService = testimonialService;
    }

    @GetMapping
    public String listTestimonials(Model model) {
        model.addAttribute("headerMessage", testimonialService.getHeaderMessage());
        model.addAttribute("testimonials", testimonialService.getAllTestimonials());
        return "testimonials";
    }

    @PostMapping("/add")
    public String addTestimonial(Testimonial testimonial) {
        testimonialService.saveTestimonial(testimonial);
        return "redirect:/testimonials";
    }
}
