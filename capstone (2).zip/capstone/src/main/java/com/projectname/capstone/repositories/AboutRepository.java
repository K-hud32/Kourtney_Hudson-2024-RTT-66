package com.projectname.capstone.repositories;

import com.projectname.capstone.models.About;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AboutRepository extends JpaRepository<About, Long> {
    // No additional methods needed; JpaRepository provides basic CRUD operations
}
