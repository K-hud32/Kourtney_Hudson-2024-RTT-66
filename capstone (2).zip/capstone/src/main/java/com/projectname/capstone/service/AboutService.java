package com.projectname.capstone.service;

import com.projectname.capstone.models.About;
import com.projectname.capstone.repositories.AboutRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AboutService {

    private final AboutRepository aboutRepository;

    @Autowired
    public AboutService(AboutRepository aboutRepository) {
        this.aboutRepository = aboutRepository;
    }

    public About getAboutInfo() {
        return aboutRepository.findById(1L).orElse(null);
    }
}
